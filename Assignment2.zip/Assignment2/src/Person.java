import java.util.Scanner;
public class Person 
{
	private String firstname,lastname;
	private char gender;
	private long phone;
	Person()
	{
		firstname="";
		lastname="";
		gender='\0';
		phone=0;
	}
	Person(String f,String l,char g,int p)
	{
		firstname=f;
		lastname=l;
		gender=g;
		phone=p;
	}
	public String getFirstname()
	{
		return firstname;
	}
	public void setFirstname(String k)
	{
		firstname=k;
	}
	public String getLastname()
	{
		return lastname;
	}
	public void setLastname(String k)
	{
		lastname=k;
	}
	public GenderEnum getGender()
	{
		Scanner sc=new Scanner(System.in);
		GenderEnum empGender = null;
		//System.out.println("Enter Gender 1:Male 2:Female ");
		//char i=sc.next().charAt(0);
		switch(gender)
		{
		case 'M':empGender=GenderEnum.M; break;
		case 'F':empGender=GenderEnum.F;
		}
		return empGender;
	}
	public void setGender(char k)
	{
		gender=k;
	}
	public long getPhoneno()
	{
		return phone;
	}
	public void setPhoneno(long k)
	{
		phone=k;
	}
}
