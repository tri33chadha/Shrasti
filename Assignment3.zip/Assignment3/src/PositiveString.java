import java.util.Scanner;

public class PositiveString
{
	public static Boolean charArray(String str)
		{
			char ch[]=str.toCharArray();
			char previous='\u0000';
			for(char current : ch)
			{
				if(previous>current)
				{
					return false;
					
				}
				previous=current;
			}
			return true;
		}
	
	public static void main(String[] args) 
	{
		String st=null;
		System.out.println("Enter The String");
		Scanner sc=new Scanner(System.in);
		st=sc.next();
		if(charArray(st)==true)
			System.out.println("Positive");
		else
			System.out.println("Negative");
	}

}
