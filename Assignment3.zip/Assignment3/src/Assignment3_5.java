import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

public class Assignment3_5 
{
	public static void warranty(LocalDate date,int years,int months)
		{
			date=date.plusYears(years);
			date=date.plusMonths(months);
			System.out.println(date);
		}
	public static void main(String[] args) 
	{
		LocalDate date=LocalDate.of(2018, Month.JUNE, 4);
		System.out.println("Enter Years & Month of Warranty:");
		Scanner sc=new Scanner(System.in);
		int years=sc.nextInt();
		int months=sc.nextInt();
		warranty(date,years,months);
	}

}
