import java.time.LocalDate;
import java.time.Month;
import java.time.Period;


public class Assignment3_4 
{

	public static void main(String[] args)
	{
		LocalDate myDay1=LocalDate.of(2014, Month.JANUARY, 4);
		LocalDate myDay2=LocalDate.of(2014, Month.JANUARY, 4);
		
		Period p=Period.between(myDay2,myDay1);
		System.out.println("Year" +p.getYears()+" Months"+p.getMonths()+"Days"+p.getDays());
					
	}

}
